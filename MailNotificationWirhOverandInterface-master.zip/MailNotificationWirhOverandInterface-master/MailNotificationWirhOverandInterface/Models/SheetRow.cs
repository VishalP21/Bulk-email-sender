namespace MailNotificationWirhOverandInterface.Models;

/// <summary>One data row from the user's original sheet, kept so the report can be written back onto it.</summary>
public class SheetRow
{
    public int RowNumber { get; set; }

    public string[] Cells { get; set; } = [];

    /// <summary>Why the importer did not load this row (duplicate, missing email, ...); null when loaded.</summary>
    public string? Issue { get; set; }
}
