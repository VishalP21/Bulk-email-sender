namespace MailNotificationWirhOverandInterface.Models;

public enum SendStatus
{
    Sent,
    Failed,
    Skipped
}

public class SendOutcome
{
    public int RowNumber { get; set; }

    public string CompanyName { get; set; } = "";

    public string Email { get; set; } = "";

    public SendStatus Status { get; set; }

    public bool Success => Status == SendStatus.Sent;

    public string Subject { get; set; } = "";

    public string Attachments { get; set; } = "";

    public DateTimeOffset? SentAt { get; set; }

    public string Detail { get; set; } = "";
}
