namespace MailNotificationWirhOverandInterface.Models;

public class SendReport
{
    public string Id { get; set; } = Guid.NewGuid().ToString("N");

    public DateTimeOffset StartedAt { get; set; }

    public DateTimeOffset FinishedAt { get; set; }

    public string FromEmail { get; set; } = "";

    public string SheetLabel { get; set; } = "";

    public bool Interrupted { get; set; }

    public int Batches { get; set; }

    public List<SendOutcome> Rows { get; set; } = [];

    /// <summary>Header row of the original sheet (for the "sheet + status" download).</summary>
    public string[] SheetHeaders { get; set; } = [];

    /// <summary>Every data row of the original sheet, including rows the importer skipped.</summary>
    public List<SheetRow> SheetRows { get; set; } = [];

    public int Total => Rows.Count;

    public int Sent => Rows.Count(row => row.Status == SendStatus.Sent);

    public int Failed => Rows.Count(row => row.Status == SendStatus.Failed);

    public int Skipped => Rows.Count(row => row.Status == SendStatus.Skipped);

    public int Attempted => Sent + Failed;

    public int SuccessRate => Attempted == 0 ? 0 : (int)Math.Round(Sent * 100.0 / Attempted);
}
