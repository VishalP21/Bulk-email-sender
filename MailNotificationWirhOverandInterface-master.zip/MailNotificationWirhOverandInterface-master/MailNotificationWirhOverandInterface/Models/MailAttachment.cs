namespace MailNotificationWirhOverandInterface.Models;

public sealed record MailAttachment(string FileName, string ContentType, byte[] Content)
{
    public static readonly IReadOnlyDictionary<string, string> AllowedTypes =
        new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
        {
            [".pdf"] = "application/pdf",
            [".doc"] = "application/msword",
            [".docx"] = "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            [".odt"] = "application/vnd.oasis.opendocument.text",
            [".rtf"] = "application/rtf",
            [".txt"] = "text/plain"
        };

    public const int MaxFiles = 5;
    public const long MaxFileBytes = 5 * 1024 * 1024;
    public const long MaxTotalBytes = 15 * 1024 * 1024;

    public static string AcceptList => string.Join(",", AllowedTypes.Keys.Concat(AllowedTypes.Values).Distinct());
}
