namespace MailNotificationWirhOverandInterface.Models;

public sealed class ReportView
{
    public required SendReport Report { get; init; }

    public HashSet<int> JustSentRows { get; init; } = [];

    /// <summary>True on the compose page: shows "next batch" / "retry failed" / "close" actions.</summary>
    public bool Live { get; init; }

    public int SendLimit { get; init; }

    public int Remaining { get; init; }

    public int Retryable { get; init; }
}
