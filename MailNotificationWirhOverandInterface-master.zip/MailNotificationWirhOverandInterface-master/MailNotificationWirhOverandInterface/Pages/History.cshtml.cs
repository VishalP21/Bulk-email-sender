using MailNotificationWirhOverandInterface.Models;
using MailNotificationWirhOverandInterface.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace MailNotificationWirhOverandInterface.Pages;

public class HistoryModel : PageModel
{
    private readonly IReportStore _reports;

    public HistoryModel(IReportStore reports)
    {
        _reports = reports;
    }

    public IReadOnlyList<SendReport> Reports { get; private set; } = [];

    public SendReport? Selected { get; private set; }

    public string? Banner { get; private set; }

    public IActionResult OnGet(string? id)
    {
        Banner = TempData["Banner"] as string;
        if (!string.IsNullOrEmpty(id))
        {
            Selected = _reports.Get(id);
            if (Selected is null)
            {
                TempData["Banner"] = "That report no longer exists.";
                return RedirectToPage(new { id = (string?)null });
            }

            return Page();
        }

        Reports = _reports.List();
        return Page();
    }

    public IActionResult OnGetDownload(string? id, string format = "xlsx")
    {
        var report = _reports.Get(id);
        if (report is null)
        {
            TempData["Banner"] = "That report no longer exists.";
            return RedirectToPage(new { id = (string?)null });
        }

        var stem = ReportExport.FileStem(report);
        const string xlsx = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
        return format.ToLowerInvariant() switch
        {
            "csv" => File(ReportExport.ToCsv(report), "text/csv", stem + ".csv"),
            "sheet" => File(ReportExport.ToSheetWithStatus(report), xlsx, stem + "-with-status.xlsx"),
            _ => File(ReportExport.ToExcel(report), xlsx, stem + "-report.xlsx")
        };
    }

    public IActionResult OnPostDelete(string? id)
    {
        TempData["Banner"] = _reports.Delete(id) ? "Deleted the report." : "That report no longer exists.";
        return RedirectToPage(new { id = (string?)null });
    }
}
