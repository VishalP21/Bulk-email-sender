using System.Text.Json;
using MailNotificationWirhOverandInterface.Models;
using MailNotificationWirhOverandInterface.Options;
using MailNotificationWirhOverandInterface.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Options;

namespace MailNotificationWirhOverandInterface.Pages;

/// <summary>How a loaded company stands before the next send.</summary>
public sealed record RowState(string Key, string Label)
{
    public static readonly RowState New = new("new", "");
}

public class IndexModel : PageModel
{
    private const string ContactsKey = "recruiter-contacts";
    private const string LabelKey = "recruiter-sheet-label";
    private const string SheetKey = "recruiter-sheet";
    private const string ReportIdKey = "recruiter-report-id";
    private const string ComposeKey = "recruiter-compose";
    private const string AttachmentsKey = "recruiter-attachments";

    private readonly ISheetImportService _sheetImport;
    private readonly IOutreachMailService _mail;
    private readonly IMailSettingsStore _settings;
    private readonly IReportStore _reports;
    private readonly OutreachOptions _options;
    private readonly ILogger<IndexModel> _logger;

    public IndexModel(
        ISheetImportService sheetImport,
        IOutreachMailService mail,
        IMailSettingsStore settings,
        IReportStore reports,
        IOptions<OutreachOptions> options,
        ILogger<IndexModel> logger)
    {
        _sheetImport = sheetImport;
        _mail = mail;
        _settings = settings;
        _reports = reports;
        _options = options.Value;
        _logger = logger;
    }

    [BindProperty]
    public IFormFile? SheetFile { get; set; }

    [BindProperty]
    public string? SheetUrl { get; set; }

    [BindProperty]
    public ComposeInput Compose { get; set; } = new();

    [BindProperty]
    public List<int> SelectedRows { get; set; } = [];

    [BindProperty]
    public List<IFormFile> Attachments { get; set; } = [];

    /// <summary>Names of files from the previous send that the user chose to keep.</summary>
    [BindProperty]
    public List<string> KeepAttachments { get; set; } = [];

    /// <summary>Set when the user knowingly re-sends to companies that were already emailed.</summary>
    [BindProperty]
    public bool AllowResend { get; set; }

    public List<RecruiterContact> Contacts { get; private set; } = [];

    public List<string> ImportNotes { get; private set; } = [];

    public SendReport? Report { get; private set; }

    public HashSet<int> JustSentRows { get; private set; } = [];

    public Dictionary<int, RowState> RowStates { get; private set; } = [];

    public List<MailAttachment> KeptAttachments { get; private set; } = [];

    public string? SheetLabel { get; private set; }

    public string? Banner { get; private set; }

    public bool BannerIsError { get; private set; }

    public string SavedFromEmail { get; private set; } = "";

    public bool HasSavedPassword { get; private set; }

    public int SendLimit => Math.Clamp(_options.MaxRecipientsPerSend, 1, 100);

    public int RemainingCount => RowStates.Values.Count(state => state.Key == "new");

    public int FailedCount => RowStates.Values.Count(state => state.Key == "failed");

    public int AlreadySentCount => RowStates.Values.Count(state => state.Key == "sent");

    public void OnGet()
    {
        LoadContacts();
        LoadReport();
        LoadNotes();
        ApplySavedProfile();
        ApplyStashedCompose();
        KeptAttachments = ReadStashedAttachments();
        ComputeRowStates();
        SelectedRows = NextBatch();
    }

    public async Task<IActionResult> OnPostImportAsync(CancellationToken cancellationToken)
    {
        ModelState.Clear();
        Stream? stream = null;
        if (SheetFile is not null)
        {
            stream = SheetFile.OpenReadStream();
        }

        var result = await _sheetImport.ImportAsync(stream, SheetFile?.FileName, SheetUrl, cancellationToken);
        if (stream is not null)
        {
            await stream.DisposeAsync();
        }

        if (!string.IsNullOrWhiteSpace(result.Error))
        {
            TempData["Banner"] = result.Error;
            TempData["BannerIsError"] = "1";
            if (result.Notes.Count > 0)
            {
                TempData["ImportNotes"] = JsonSerializer.Serialize(result.Notes);
            }

            return RedirectToPage();
        }

        HttpContext.Session.SetString(ContactsKey, JsonSerializer.Serialize(result.Contacts));
        HttpContext.Session.SetString(LabelKey, result.Label);
        HttpContext.Session.SetString(SheetKey, JsonSerializer.Serialize(new SheetSnapshot(result.Headers, result.Rows)));
        HttpContext.Session.Remove(ReportIdKey);

        // Same sheet loaded again (even after a restart)? Continue its report instead of starting over.
        var resumable = _reports.FindResumable(result.Label, result.Contacts.Select(contact => contact.Email));
        if (resumable is not null && resumable.Skipped + resumable.Failed > 0)
        {
            HttpContext.Session.SetString(ReportIdKey, resumable.Id);
            result.Notes.Add($"Continuing your report from {resumable.FinishedAt.ToLocalTime():dd MMM, HH:mm}: {resumable.Sent} already sent, {resumable.Failed} failed. Close the report to start a new one.");
        }

        var history = _reports.LastSentByEmail();
        var emailedBefore = result.Contacts.Count(contact => history.ContainsKey(contact.Email));
        if (emailedBefore > 0)
        {
            result.Notes.Add($"{emailedBefore} {(emailedBefore == 1 ? "company was" : "companies were")} already emailed earlier. They are marked and left unticked.");
        }

        TempData["ImportNotes"] = JsonSerializer.Serialize(result.Notes);
        TempData["Banner"] = result.Notes.FirstOrDefault() ?? "Sheet loaded.";
        return RedirectToPage();
    }

    public IActionResult OnPostClear()
    {
        foreach (var key in new[] { ContactsKey, LabelKey, SheetKey, ReportIdKey })
        {
            HttpContext.Session.Remove(key);
        }

        TempData["Banner"] = "Cleared the company list. Past reports are still in History.";
        return RedirectToPage();
    }

    public IActionResult OnPostCloseReport()
    {
        HttpContext.Session.Remove(ReportIdKey);
        TempData["Banner"] = "Closed the report. It is saved in History, and the next send starts a new report.";
        return RedirectToPage();
    }

    public async Task<IActionResult> OnPostSendAsync(CancellationToken cancellationToken)
    {
        LoadContacts();
        LoadReport();
        ApplySavedMailAccount();
        ComputeRowStates();

        // The mail account comes from Settings, not from this form, so drop the binder's
        // checks on those empty form values and validate the saved values below instead.
        foreach (var key in new[] { "Compose.FromEmail", "Compose.FromPassword", "Compose.Host", "Compose.Port" })
        {
            ModelState.Remove(key);
        }

        if (!Compose.Confirmed)
        {
            ModelState.AddModelError(nameof(Compose.Confirmed), "Confirm that you want to contact the selected companies.");
        }

        if (string.IsNullOrWhiteSpace(Compose.FromEmail) || string.IsNullOrWhiteSpace(Compose.FromPassword))
        {
            ModelState.AddModelError(string.Empty, "Open Settings and save your email and app password.");
        }

        if (string.IsNullOrWhiteSpace(Compose.Host) || Compose.Host.Contains('/') || Compose.Host.Contains(' '))
        {
            ModelState.AddModelError(string.Empty, "In Settings, enter a mail server such as smtp.gmail.com.");
        }

        var attachments = await ReadAttachmentsAsync(cancellationToken);
        StashAttachments(attachments);
        KeptAttachments = attachments;

        var selected = Contacts
            .Where(contact => SelectedRows.Contains(contact.RowNumber))
            .DistinctBy(contact => contact.Email, StringComparer.OrdinalIgnoreCase)
            .ToList();
        var resends = selected.Count(contact => StateOf(contact).Key == "sent");
        if (selected.Count == 0)
        {
            ModelState.AddModelError(string.Empty, "Tick at least one company.");
        }
        else if (selected.Count > SendLimit)
        {
            ModelState.AddModelError(string.Empty, $"Send up to {SendLimit} companies at a time. Untick the rest and send again.");
        }

        if (resends > 0 && !AllowResend)
        {
            ModelState.AddModelError(string.Empty,
                $"{resends} ticked {(resends == 1 ? "company was" : "companies were")} already emailed. Untick {(resends == 1 ? "it" : "them")}, or tick “Send again anyway”.");
        }

        if (!ModelState.IsValid)
        {
            Banner = "Fix the highlighted fields, then send again.";
            BannerIsError = true;
            ClearPassword();
            return Page();
        }

        StashCompose();

        var startedAt = DateTimeOffset.Now;
        var outcomes = new List<SendOutcome>();
        var interrupted = false;
        try
        {
            await _mail.SendAsync(selected, Compose, attachments, outcomes, cancellationToken);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Outreach send stopped");
            interrupted = true;
        }

        SaveReport(outcomes, startedAt, interrupted);

        var sent = outcomes.Count(outcome => outcome.Success);
        var failed = outcomes.Count - sent;
        var notReached = selected.Count - outcomes.Count;
        string banner;
        if (interrupted)
        {
            banner = $"Sending stopped early. Sent {sent}, failed {failed}, {notReached} not reached. Check the report and send the rest again.";
        }
        else
        {
            banner = sent == 0
                ? $"No mail was sent. {failed} {(failed == 1 ? "company" : "companies")} failed."
                : failed == 0
                    ? $"Sent {sent} {(sent == 1 ? "mail" : "mails")}."
                    : $"Sent {sent}. {failed} could not be sent.";
        }

        // Post/Redirect/Get: refreshing the page can never send the same batch twice.
        TempData["Banner"] = banner;
        TempData["BannerIsError"] = interrupted || failed > 0 ? "1" : "0";
        TempData["JustSent"] = JsonSerializer.Serialize(outcomes.Select(outcome => outcome.RowNumber));
        return RedirectToPage(null, null, "report");
    }

    public RowState StateOf(RecruiterContact contact) =>
        RowStates.TryGetValue(contact.RowNumber, out var state) ? state : RowState.New;

    private void ComputeRowStates()
    {
        var current = Report?.Rows.ToDictionary(row => row.RowNumber) ?? [];
        var history = _reports.LastSentByEmail();
        RowStates = [];
        foreach (var contact in Contacts)
        {
            current.TryGetValue(contact.RowNumber, out var row);
            if (row is { Status: SendStatus.Sent })
            {
                RowStates[contact.RowNumber] = new RowState("sent", $"Sent {row.SentAt?.ToLocalTime():dd MMM}");
            }
            else if (history.TryGetValue(contact.Email, out var at))
            {
                RowStates[contact.RowNumber] = new RowState("sent", $"Emailed {at.ToLocalTime():dd MMM}");
            }
            else if (row is { Status: SendStatus.Failed })
            {
                RowStates[contact.RowNumber] = new RowState("failed", "Failed");
            }
            else
            {
                RowStates[contact.RowNumber] = RowState.New;
            }
        }
    }

    private List<int> NextBatch() =>
        Contacts
            .Where(contact => StateOf(contact).Key == "new")
            .OrderBy(contact => contact.RowNumber)
            .Take(SendLimit)
            .Select(contact => contact.RowNumber)
            .ToList();

    private async Task<List<MailAttachment>> ReadAttachmentsAsync(CancellationToken cancellationToken)
    {
        var result = ReadStashedAttachments()
            .Where(file => KeepAttachments.Contains(file.FileName))
            .ToList();

        foreach (var file in Attachments.Where(file => file is { Length: > 0 }))
        {
            var name = Path.GetFileName(file.FileName);
            var extension = Path.GetExtension(name);
            if (!MailAttachment.AllowedTypes.TryGetValue(extension, out var contentType))
            {
                ModelState.AddModelError(nameof(Attachments), $"{name}: only PDF, Word (DOC, DOCX), ODT, RTF or TXT files can be attached.");
                continue;
            }

            if (file.Length > MailAttachment.MaxFileBytes)
            {
                ModelState.AddModelError(nameof(Attachments), $"{name} is larger than {MailAttachment.MaxFileBytes / 1024 / 1024} MB.");
                continue;
            }

            await using var memory = new MemoryStream();
            await file.CopyToAsync(memory, cancellationToken);
            result.RemoveAll(existing => existing.FileName.Equals(name, StringComparison.OrdinalIgnoreCase));
            result.Add(new MailAttachment(name, contentType, memory.ToArray()));
        }

        if (result.Count > MailAttachment.MaxFiles)
        {
            ModelState.AddModelError(nameof(Attachments), $"Attach up to {MailAttachment.MaxFiles} files.");
        }

        if (result.Sum(file => (long)file.Content.Length) > MailAttachment.MaxTotalBytes)
        {
            ModelState.AddModelError(nameof(Attachments), $"All files together must be under {MailAttachment.MaxTotalBytes / 1024 / 1024} MB.");
        }

        return result;
    }

    private List<MailAttachment> ReadStashedAttachments()
    {
        var bytes = HttpContext.Session.Get(AttachmentsKey);
        return bytes is null ? [] : JsonSerializer.Deserialize<List<MailAttachment>>(bytes) ?? [];
    }

    private void StashAttachments(List<MailAttachment> attachments)
    {
        if (attachments.Count == 0)
        {
            HttpContext.Session.Remove(AttachmentsKey);
        }
        else
        {
            HttpContext.Session.Set(AttachmentsKey, JsonSerializer.SerializeToUtf8Bytes(attachments));
        }
    }

    private void StashCompose()
    {
        var copy = new ComposeInput
        {
            YourName = Compose.YourName,
            Role = Compose.Role,
            Phone = Compose.Phone,
            Link = Compose.Link,
            Extra = Compose.Extra,
            Subject = Compose.Subject,
            Body = Compose.Body
        };
        HttpContext.Session.SetString(ComposeKey, JsonSerializer.Serialize(copy));
    }

    private void ApplyStashedCompose()
    {
        var json = HttpContext.Session.GetString(ComposeKey);
        if (string.IsNullOrWhiteSpace(json) || JsonSerializer.Deserialize<ComposeInput>(json) is not { } saved)
        {
            return;
        }

        Compose.YourName = saved.YourName;
        Compose.Role = saved.Role;
        Compose.Phone = saved.Phone;
        Compose.Link = saved.Link;
        Compose.Extra = saved.Extra;
        Compose.Subject = saved.Subject;
        Compose.Body = saved.Body;
    }

    private void ClearPassword()
    {
        Compose.FromPassword = "";
        ModelState.Remove("Compose.FromPassword");
    }

    private void SaveReport(List<SendOutcome> outcomes, DateTimeOffset startedAt, bool interrupted)
    {
        // Keep earlier batches for the same sheet so the report covers every row, not just this send.
        var label = SheetLabel ?? "";
        var existing = Report is not null && Report.SheetLabel == label ? Report : null;
        var previous = existing?.Rows.ToDictionary(row => row.RowNumber) ?? [];
        var latest = outcomes.ToDictionary(outcome => outcome.RowNumber);
        var sheet = LoadSheet();

        var rows = Contacts
            .OrderBy(contact => contact.RowNumber)
            .Select(contact =>
                latest.TryGetValue(contact.RowNumber, out var fresh) ? fresh
                : previous.TryGetValue(contact.RowNumber, out var old) ? old
                : new SendOutcome
                {
                    RowNumber = contact.RowNumber,
                    CompanyName = contact.CompanyName,
                    Email = contact.Email,
                    Status = SendStatus.Skipped,
                    Detail = "Not sent yet"
                })
            .ToList();

        Report = new SendReport
        {
            Id = existing?.Id ?? Guid.NewGuid().ToString("N"),
            StartedAt = existing?.StartedAt ?? startedAt,
            FinishedAt = DateTimeOffset.Now,
            FromEmail = Compose.FromEmail,
            SheetLabel = label,
            Interrupted = interrupted,
            Batches = (existing?.Batches ?? 0) + 1,
            Rows = rows,
            SheetHeaders = sheet?.Headers ?? existing?.SheetHeaders ?? [],
            SheetRows = sheet?.Rows ?? existing?.SheetRows ?? []
        };

        _reports.Save(Report);
        HttpContext.Session.SetString(ReportIdKey, Report.Id);
    }

    private void LoadReport()
    {
        Report = _reports.Get(HttpContext.Session.GetString(ReportIdKey));
    }

    private SheetSnapshot? LoadSheet()
    {
        var json = HttpContext.Session.GetString(SheetKey);
        return string.IsNullOrWhiteSpace(json) ? null : JsonSerializer.Deserialize<SheetSnapshot>(json);
    }

    private void LoadContacts()
    {
        var json = HttpContext.Session.GetString(ContactsKey);
        Contacts = string.IsNullOrWhiteSpace(json)
            ? []
            : JsonSerializer.Deserialize<List<RecruiterContact>>(json) ?? [];
        SheetLabel = HttpContext.Session.GetString(LabelKey);
    }

    private void ApplySavedProfile()
    {
        var saved = _settings.Get();
        SavedFromEmail = saved.FromEmail;
        HasSavedPassword = saved.HasPassword;
        if (!string.IsNullOrWhiteSpace(saved.YourName))
        {
            Compose.YourName = saved.YourName;
        }

        if (!string.IsNullOrWhiteSpace(saved.Role))
        {
            Compose.Role = saved.Role;
        }

        if (!string.IsNullOrWhiteSpace(saved.Phone))
        {
            Compose.Phone = saved.Phone;
        }

        if (!string.IsNullOrWhiteSpace(saved.Link))
        {
            Compose.Link = saved.Link;
        }

        if (!string.IsNullOrWhiteSpace(saved.Subject))
        {
            Compose.Subject = saved.Subject;
        }

        if (!string.IsNullOrWhiteSpace(saved.Body))
        {
            Compose.Body = saved.Body;
        }
    }

    private void ApplySavedMailAccount()
    {
        var saved = _settings.Get();
        SavedFromEmail = saved.FromEmail;
        HasSavedPassword = saved.HasPassword;
        Compose.FromEmail = saved.FromEmail;
        Compose.FromPassword = _settings.ReadPassword() ?? "";
        Compose.Host = string.IsNullOrWhiteSpace(saved.Host) ? "smtp.gmail.com" : saved.Host;
        Compose.Port = saved.Port is < 1 or > 65535 ? 587 : saved.Port;
    }

    private void LoadNotes()
    {
        if (TempData["Banner"] is string banner)
        {
            Banner = banner;
            BannerIsError = TempData["BannerIsError"] as string == "1";
        }

        if (TempData["ImportNotes"] is string notesJson)
        {
            ImportNotes = JsonSerializer.Deserialize<List<string>>(notesJson) ?? [];
        }

        if (TempData["JustSent"] is string sentJson)
        {
            JustSentRows = JsonSerializer.Deserialize<HashSet<int>>(sentJson) ?? [];
        }
    }

    private sealed record SheetSnapshot(string[] Headers, List<SheetRow> Rows);
}
