(function () {
    "use strict";

    const $ = (id) => document.getElementById(id);

    const subject = $("Compose_Subject");
    const body = $("Compose_Body");
    const previewSubject = $("preview-subject");
    const previewBody = $("preview-body");
    const previewTo = $("preview-to");
    const selectAll = $("select-all");
    const sendForm = $("send-form");
    const sendBtn = $("send-btn");
    const selectedCount = $("selected-count");
    const summaryCompanies = $("summary-companies");
    const filter = $("company-filter");

    /* ------------------------------------------------------------------
       Preview
       ------------------------------------------------------------------ */
    function value(id) {
        const element = $(id);
        return element ? element.value.trim() : "";
    }

    function firstPickedRow() {
        const picked = document.querySelector(".companies tbody tr .pick:checked");
        return picked ? picked.closest("tr") : null;
    }

    function fill(template) {
        const row = firstPickedRow();
        const tokens = {
            CompanyName: row ? row.dataset.company : "the company",
            YourName: value("Compose_YourName"),
            Role: value("Compose_Role"),
            Phone: value("Compose_Phone"),
            Link: value("Compose_Link"),
            Extra: value("Compose_Extra")
        };
        return template.replace(/\{\{\s*(\w+)\s*\}\}/g, function (_, key) {
            const match = Object.keys(tokens).find((k) => k.toLowerCase() === key.toLowerCase());
            return match ? tokens[match] : "";
        }).replace(/[ \t]+\n/g, "\n").replace(/(\n\s*){3,}/g, "\n\n").trim();
    }

    function renderPreview() {
        if (!subject || !body || !previewSubject || !previewBody) {
            return;
        }
        previewSubject.textContent = fill(subject.value).replace(/\s+/g, " ") || "(no subject)";
        previewBody.textContent = fill(body.value);
        if (previewTo) {
            const row = firstPickedRow();
            previewTo.textContent = row ? row.dataset.company + " <" + row.dataset.email + ">" : "First selected company";
        }
    }

    /* ------------------------------------------------------------------
       Recipients: counts, select all, filter
       ------------------------------------------------------------------ */
    function picks() {
        return Array.from(document.querySelectorAll(".pick"));
    }

    function updateCounts() {
        const boxes = picks();
        const checked = boxes.filter((box) => box.checked).length;
        if (selectedCount) selectedCount.textContent = checked;
        if (summaryCompanies) summaryCompanies.textContent = checked;
        if (selectAll && boxes.length) {
            selectAll.checked = checked === boxes.length;
            selectAll.indeterminate = checked > 0 && checked < boxes.length;
        }
        if (sendBtn && boxes.length) {
            sendBtn.disabled = checked === 0;
        }

        // Warn when a ticked company was already emailed (server also blocks it).
        const resendBox = $("resend-warning");
        if (resendBox) {
            const resends = boxes.filter((box) => box.checked && box.closest("tr").dataset.state === "sent").length;
            const resendCount = $("resend-count");
            if (resendCount) resendCount.textContent = resends;
            resendBox.hidden = resends === 0;
        }
    }

    /* Quick select: next unsent batch, failed only, or none. */
    const recipients = $("recipients");
    function pick(mode) {
        if (!recipients) return;
        const limit = Number(recipients.dataset.limit) || 30;
        let taken = 0;
        recipients.querySelectorAll("tbody tr[data-company]").forEach(function (row) {
            const box = row.querySelector(".pick");
            const wanted = (mode === "next" && row.dataset.state === "new") ||
                (mode === "failed" && row.dataset.state === "failed");
            box.checked = wanted && taken < limit;
            if (box.checked) taken++;
        });
        if (filter) {
            filter.value = "";
            filter.dispatchEvent(new Event("input"));
        }
        updateCounts();
        renderPreview();
    }

    document.querySelectorAll("[data-pick]").forEach(function (button) {
        button.addEventListener("click", function () {
            pick(button.dataset.pick);
            // Buttons in the report jump back up to the company list.
            if (button.closest("#report") && recipients) {
                recipients.closest("section").scrollIntoView({ behavior: "smooth", block: "start" });
            }
        });
    });

    /* Confirm destructive forms (e.g. delete report). */
    document.querySelectorAll("form[data-confirm]").forEach(function (form) {
        form.addEventListener("submit", function (event) {
            if (!window.confirm(form.dataset.confirm)) event.preventDefault();
        });
    });

    if (selectAll) {
        selectAll.addEventListener("change", function () {
            // Only toggle rows that are visible under the current filter.
            picks().forEach(function (box) {
                if (!box.closest("tr").hidden) box.checked = selectAll.checked;
            });
            updateCounts();
            renderPreview();
        });
    }

    if (filter) {
        filter.addEventListener("input", function () {
            const term = filter.value.trim().toLowerCase();
            document.querySelectorAll(".companies tbody tr[data-company]").forEach(function (row) {
                const text = (row.dataset.company + " " + row.dataset.email).toLowerCase();
                row.hidden = term !== "" && !text.includes(term);
            });
        });
    }

    /* ------------------------------------------------------------------
       Placeholder chips: insert at cursor in subject or message
       ------------------------------------------------------------------ */
    let lastField = body;
    [subject, body].forEach(function (field) {
        if (field) field.addEventListener("focus", function () { lastField = field; });
    });

    document.querySelectorAll(".token").forEach(function (chip) {
        chip.addEventListener("click", function () {
            if (!lastField) return;
            const text = "{{" + chip.dataset.token + "}}";
            const start = lastField.selectionStart ?? lastField.value.length;
            const end = lastField.selectionEnd ?? lastField.value.length;
            lastField.setRangeText(text, start, end, "end");
            lastField.focus();
            renderPreview();
        });
    });

    /* ------------------------------------------------------------------
       Attachments
       ------------------------------------------------------------------ */
    const dropzone = $("dropzone");
    const fileInput = $("Attachments");
    const fileList = $("file-list");
    const fileError = $("file-error");
    const summaryFiles = $("summary-files");
    const previewFiles = $("preview-files");
    const previewFilesRow = $("preview-files-row");
    let files = [];
    const keptList = $("kept-list");

    function keptItems() {
        return keptList ? Array.from(keptList.querySelectorAll(".file-item")) : [];
    }

    function keptSize() {
        return keptItems().reduce((sum, item) => sum + Number(item.dataset.size || 0), 0);
    }

    keptItems().forEach(function (item) {
        item.querySelector(".file-remove").addEventListener("click", function () {
            item.remove(); // its hidden KeepAttachments input goes with it
            showError("");
            renderFiles();
        });
    });

    function formatSize(bytes) {
        if (bytes < 1024) return bytes + " B";
        if (bytes < 1024 * 1024) return Math.round(bytes / 1024) + " KB";
        return (bytes / 1024 / 1024).toFixed(1) + " MB";
    }

    function extensionOf(name) {
        const dot = name.lastIndexOf(".");
        return dot >= 0 ? name.slice(dot).toLowerCase() : "";
    }

    function syncInput() {
        // Push the managed list back into the real <input> so the form submits it.
        if (!fileInput || typeof DataTransfer === "undefined") return;
        const transfer = new DataTransfer();
        files.forEach((file) => transfer.items.add(file));
        fileInput.files = transfer.files;
    }

    function renderFiles() {
        if (!fileList) return;
        fileList.innerHTML = "";
        files.forEach(function (file, index) {
            const ext = extensionOf(file.name).replace(".", "").toUpperCase() || "FILE";
            const kind = ext === "PDF" ? "is-pdf" : (ext === "DOC" || ext === "DOCX") ? "is-doc" : "";

            const item = document.createElement("li");
            item.className = "file-item";

            const badge = document.createElement("span");
            badge.className = "file-type " + kind;
            badge.setAttribute("aria-hidden", "true");
            badge.textContent = ext.slice(0, 4);

            const info = document.createElement("span");
            info.className = "file-info";
            const name = document.createElement("span");
            name.className = "file-name";
            name.title = file.name;
            name.textContent = file.name;
            const size = document.createElement("span");
            size.className = "file-size";
            size.textContent = formatSize(file.size);
            info.append(name, size);

            const remove = document.createElement("button");
            remove.type = "button";
            remove.className = "file-remove";
            remove.setAttribute("aria-label", "Remove " + file.name);
            remove.innerHTML = '<svg class="icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M18 6 6 18M6 6l12 12"/></svg>';
            remove.addEventListener("click", function () {
                files.splice(index, 1);
                showError("");
                commit();
                if (fileInput) fileInput.focus();
            });

            item.append(badge, info, remove);
            fileList.appendChild(item);
        });

        const names = keptItems().map((item) => item.dataset.name).concat(files.map((f) => f.name));
        const total = files.reduce((sum, f) => sum + f.size, 0) + keptSize();
        const label = names.length === 0
            ? "None"
            : names.length + (names.length === 1 ? " file" : " files") + " · " + formatSize(total);
        if (summaryFiles) summaryFiles.textContent = label;
        if (previewFiles && previewFilesRow) {
            previewFilesRow.hidden = names.length === 0;
            previewFiles.textContent = names.join(", ");
        }
    }

    function commit() {
        syncInput();
        renderFiles();
    }

    function showError(message) {
        if (fileError) fileError.textContent = message;
    }

    function addFiles(incoming) {
        if (!dropzone) return;
        const maxFiles = Number(dropzone.dataset.maxFiles);
        const maxFile = Number(dropzone.dataset.maxFile);
        const maxTotal = Number(dropzone.dataset.maxTotal);
        const allowed = (dropzone.dataset.allowed || "").split(",");
        const problems = [];

        Array.from(incoming).forEach(function (file) {
            if (!allowed.includes(extensionOf(file.name))) {
                problems.push(file.name + " is not a supported document type.");
                return;
            }
            if (file.size > maxFile) {
                problems.push(file.name + " is larger than " + formatSize(maxFile) + ".");
                return;
            }
            if (files.some((f) => f.name === file.name && f.size === file.size)) {
                return; // already attached
            }
            // A new upload with the same name replaces a kept file.
            keptItems().forEach(function (item) {
                if (item.dataset.name.toLowerCase() === file.name.toLowerCase()) item.remove();
            });
            if (files.length + keptItems().length >= maxFiles) {
                problems.push("You can attach up to " + maxFiles + " files.");
                return;
            }
            const total = files.reduce((sum, f) => sum + f.size, 0) + keptSize() + file.size;
            if (total > maxTotal) {
                problems.push(file.name + " would take the total over " + formatSize(maxTotal) + ".");
                return;
            }
            files.push(file);
        });

        showError(Array.from(new Set(problems)).join(" "));
        commit();
    }

    if (fileInput && dropzone) {
        fileInput.addEventListener("change", function (event) {
            event.stopPropagation();
            const picked = Array.from(fileInput.files || []);
            addFiles(picked);
        });

        ["dragenter", "dragover"].forEach(function (type) {
            dropzone.addEventListener(type, function (event) {
                event.preventDefault();
                dropzone.classList.add("is-over");
            });
        });
        ["dragleave", "dragend", "drop"].forEach(function (type) {
            dropzone.addEventListener(type, function (event) {
                if (type === "dragleave" && dropzone.contains(event.relatedTarget)) return;
                dropzone.classList.remove("is-over");
            });
        });
        dropzone.addEventListener("drop", function (event) {
            event.preventDefault();
            if (event.dataTransfer && event.dataTransfer.files.length) {
                addFiles(event.dataTransfer.files);
            }
        });

        // Stop the browser from opening a file dropped outside the zone.
        window.addEventListener("dragover", (e) => e.preventDefault());
        window.addEventListener("drop", (e) => e.preventDefault());
    }

    /* ------------------------------------------------------------------
       Global listeners + submit state
       ------------------------------------------------------------------ */
    document.addEventListener("input", renderPreview);
    document.addEventListener("change", function (event) {
        if (event.target.classList && event.target.classList.contains("pick")) {
            updateCounts();
        }
        renderPreview();
    });

    if (sendForm && sendBtn) {
        sendForm.addEventListener("submit", function (event) {
            if (event.submitter !== sendBtn) return;
            // Defer so the button's value is still part of the submission.
            setTimeout(function () {
                sendBtn.disabled = true;
                sendBtn.innerHTML = '<span class="spinner" aria-hidden="true"></span><span>Sending…</span>';
            }, 0);
        });
    }

    /* ------------------------------------------------------------------
       Send report: status filter + search
       ------------------------------------------------------------------ */
    const report = $("report");
    if (report) {
        const reportFilter = $("report-filter");
        const segs = Array.from(report.querySelectorAll(".seg"));
        const rows = Array.from(report.querySelectorAll("tbody tr[data-status]"));
        const noMatch = report.querySelector(".no-match");
        let status = "all";

        const applyReportFilter = function () {
            const term = reportFilter ? reportFilter.value.trim().toLowerCase() : "";
            let shown = 0;
            rows.forEach(function (row) {
                const visible = (status === "all" || row.dataset.status === status) &&
                    (term === "" || row.dataset.search.includes(term));
                row.hidden = !visible;
                if (visible) shown++;
            });
            if (noMatch) noMatch.hidden = shown > 0;
        };

        segs.forEach(function (seg) {
            seg.addEventListener("click", function () {
                status = seg.dataset.status;
                segs.forEach(function (s) {
                    s.classList.toggle("is-active", s === seg);
                    s.setAttribute("aria-pressed", s === seg ? "true" : "false");
                });
                applyReportFilter();
            });
        });
        if (reportFilter) reportFilter.addEventListener("input", applyReportFilter);

        // After a send, bring the report into view.
        if (report.dataset.justSent === "1") {
            const smooth = !window.matchMedia("(prefers-reduced-motion: reduce)").matches;
            report.scrollIntoView({ behavior: smooth ? "smooth" : "auto", block: "start" });
        }
    }

    renderFiles();
    updateCounts();
    renderPreview();
})();
