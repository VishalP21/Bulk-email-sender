﻿using System.Net;
using System.Net.Mail;
using MailNotificationWirhOverandInterface.Models;

namespace MailNotificationWirhOverandInterface
{
    public class mailNotification : SMTPConfrig, INotification
    {
        public override void SetEmailConfiguration()
        {
            Host = "smtp.gmail.com";
            Port = 587;
            EnableSsl = true;
            FromPassword = "";
            FromEmail = "";
            FromName = "";
        }

        public bool SendNotification(string to, string title, string message1)
        {
            return TrySend(to, title, message1, null, out _);
        }

        public bool TrySend(
            string to,
            string title,
            string htmlBody,
            IReadOnlyList<MailAttachment>? attachments,
            out string error)
        {
            error = "";

            if (string.IsNullOrWhiteSpace(Host) || Port <= 0)
            {
                SetEmailConfiguration();
            }

            if (string.IsNullOrWhiteSpace(FromEmail) || string.IsNullOrWhiteSpace(FromPassword))
            {
                error = "Mail account is missing an email or app password.";
                return false;
            }

            try
            {
                using var smtp = new SmtpClient
                {
                    Host = Host,
                    Port = Port,
                    EnableSsl = EnableSsl,
                    DeliveryMethod = SmtpDeliveryMethod.Network,
                    UseDefaultCredentials = false,
                    Credentials = new NetworkCredential(FromEmail, FromPassword),
                    Timeout = 30000
                };

                using var message = new MailMessage
                {
                    From = string.IsNullOrWhiteSpace(FromName)
                        ? new MailAddress(FromEmail)
                        : new MailAddress(FromEmail, FromName),
                    Subject = title,
                    Body = htmlBody,
                    IsBodyHtml = true
                };
                message.To.Add(to);

                foreach (var file in attachments ?? [])
                {
                    if (file.Content.Length == 0 || string.IsNullOrWhiteSpace(file.FileName))
                    {
                        continue;
                    }

                    // MailMessage.Dispose disposes each attachment and its stream.
                    var stream = new MemoryStream(file.Content, writable: false);
                    message.Attachments.Add(new Attachment(stream, file.FileName, file.ContentType));
                }

                smtp.Send(message);
                return true;
            }
            catch (Exception ex)
            {
                // SmtpException often says only "Failure sending mail."; the real cause is inside.
                var root = ex;
                while (root.InnerException is not null)
                {
                    root = root.InnerException;
                }

                error = root == ex ? ex.Message : $"{ex.Message} {root.Message}";
                return false;
            }
        }
    }
}
