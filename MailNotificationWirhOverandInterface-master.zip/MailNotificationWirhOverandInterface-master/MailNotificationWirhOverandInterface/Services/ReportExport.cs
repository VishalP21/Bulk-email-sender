using System.Text;
using ClosedXML.Excel;
using MailNotificationWirhOverandInterface.Models;

namespace MailNotificationWirhOverandInterface.Services;

public static class ReportExport
{
    private static readonly string[] Headers =
        ["#", "Sheet row", "Company", "Email", "Status", "Sent at", "Subject", "Attachments", "Details"];

    public static string FileStem(SendReport report)
    {
        var name = Path.GetFileNameWithoutExtension(report.SheetLabel);
        var safe = new string(name.Select(c => char.IsLetterOrDigit(c) || c is '-' or '_' ? c : '-').ToArray()).Trim('-');
        if (safe.Length > 40)
        {
            safe = safe[..40];
        }

        var prefix = string.IsNullOrEmpty(safe) ? "send-report" : safe;
        return $"{prefix}-{report.FinishedAt.ToLocalTime():yyyy-MM-dd-HHmm}";
    }

    public static byte[] ToExcel(SendReport report)
    {
        using var workbook = new XLWorkbook();

        var summary = workbook.Worksheets.Add("Summary");
        var lines = new (string Label, string Value)[]
        {
            ("Sheet", report.SheetLabel),
            ("Sent from", report.FromEmail),
            ("Started", report.StartedAt.ToLocalTime().ToString("yyyy-MM-dd HH:mm:ss")),
            ("Finished", report.FinishedAt.ToLocalTime().ToString("yyyy-MM-dd HH:mm:ss")),
            ("Companies in sheet", report.Total.ToString()),
            ("Sent", report.Sent.ToString()),
            ("Failed", report.Failed.ToString()),
            ("Not sent yet", report.Skipped.ToString()),
            ("Success rate (of attempted)", $"{report.SuccessRate}%"),
            ("Stopped early", report.Interrupted ? "Yes" : "No")
        };
        for (var i = 0; i < lines.Length; i++)
        {
            summary.Cell(i + 1, 1).Value = lines[i].Label;
            summary.Cell(i + 1, 1).Style.Font.Bold = true;
            summary.Cell(i + 1, 2).Value = lines[i].Value;
        }

        summary.Columns().AdjustToContents();

        var details = workbook.Worksheets.Add("Details");
        for (var col = 0; col < Headers.Length; col++)
        {
            details.Cell(1, col + 1).Value = Headers[col];
        }

        var header = details.Range(1, 1, 1, Headers.Length);
        header.Style.Font.Bold = true;
        header.Style.Font.FontColor = XLColor.White;
        header.Style.Fill.BackgroundColor = XLColor.FromHtml("#0F766E");

        for (var i = 0; i < report.Rows.Count; i++)
        {
            var row = report.Rows[i];
            var r = i + 2;
            details.Cell(r, 1).Value = i + 1;
            details.Cell(r, 2).Value = row.RowNumber;
            details.Cell(r, 3).Value = row.CompanyName;
            details.Cell(r, 4).Value = row.Email;
            details.Cell(r, 5).Value = StatusLabel(row.Status);
            if (row.SentAt is { } at)
            {
                details.Cell(r, 6).Value = at.ToLocalTime().DateTime;
                details.Cell(r, 6).Style.DateFormat.Format = "yyyy-mm-dd hh:mm:ss";
            }

            details.Cell(r, 7).Value = row.Subject;
            details.Cell(r, 8).Value = row.Attachments;
            details.Cell(r, 9).Value = row.Detail;

            Paint(details.Cell(r, 5).Style, row.Status);
        }

        details.Range(1, 1, report.Rows.Count + 1, Headers.Length).SetAutoFilter();
        details.SheetView.FreezeRows(1);
        details.Columns().AdjustToContents(8.0, 60.0);

        using var stream = new MemoryStream();
        workbook.SaveAs(stream);
        return stream.ToArray();
    }

    /// <summary>The user's original sheet with three status columns added at the end.</summary>
    public static byte[] ToSheetWithStatus(SendReport report)
    {
        using var workbook = new XLWorkbook();
        var sheet = workbook.Worksheets.Add("Sheet with status");
        var outcomes = report.Rows.ToDictionary(row => row.RowNumber);
        var width = Math.Max(report.SheetHeaders.Length, report.SheetRows.Count == 0 ? 0 : report.SheetRows.Max(row => row.Cells.Length));
        var headers = report.SheetHeaders.Concat(Enumerable.Range(report.SheetHeaders.Length + 1, Math.Max(0, width - report.SheetHeaders.Length)).Select(i => $"Column {i}")).ToArray();

        for (var col = 0; col < headers.Length; col++)
        {
            sheet.Cell(1, col + 1).Value = headers[col];
        }

        var statusCol = headers.Length + 1;
        sheet.Cell(1, statusCol).Value = "Send status";
        sheet.Cell(1, statusCol + 1).Value = "Sent at";
        sheet.Cell(1, statusCol + 2).Value = "Send details";
        var header = sheet.Range(1, 1, 1, statusCol + 2);
        header.Style.Font.Bold = true;
        sheet.Range(1, statusCol, 1, statusCol + 2).Style.Fill.BackgroundColor = XLColor.FromHtml("#0F766E");
        sheet.Range(1, statusCol, 1, statusCol + 2).Style.Font.FontColor = XLColor.White;

        // Older reports made before sheet rows were stored: fall back to the report rows.
        var rows = report.SheetRows.Count > 0
            ? report.SheetRows
            : report.Rows.Select(row => new SheetRow { RowNumber = row.RowNumber, Cells = [row.CompanyName, row.Email] }).ToList();

        var r = 2;
        foreach (var row in rows.OrderBy(row => row.RowNumber))
        {
            for (var col = 0; col < row.Cells.Length; col++)
            {
                sheet.Cell(r, col + 1).Value = row.Cells[col];
            }

            var status = sheet.Cell(r, statusCol);
            if (outcomes.TryGetValue(row.RowNumber, out var outcome))
            {
                status.Value = StatusLabel(outcome.Status);
                if (outcome.SentAt is { } at)
                {
                    sheet.Cell(r, statusCol + 1).Value = at.ToLocalTime().DateTime;
                    sheet.Cell(r, statusCol + 1).Style.DateFormat.Format = "yyyy-mm-dd hh:mm:ss";
                }

                sheet.Cell(r, statusCol + 2).Value = outcome.Detail;
                Paint(status.Style, outcome.Status);
            }
            else
            {
                status.Value = "Not loaded";
                sheet.Cell(r, statusCol + 2).Value = row.Issue ?? "";
                Paint(status.Style, SendStatus.Skipped);
            }

            r++;
        }

        sheet.Range(1, 1, Math.Max(1, r - 1), statusCol + 2).SetAutoFilter();
        sheet.SheetView.FreezeRows(1);
        sheet.Columns().AdjustToContents(8.0, 60.0);

        using var stream = new MemoryStream();
        workbook.SaveAs(stream);
        return stream.ToArray();
    }

    private static void Paint(IXLStyle style, SendStatus status)
    {
        style.Font.Bold = true;
        (style.Fill.BackgroundColor, style.Font.FontColor) = status switch
        {
            SendStatus.Sent => (XLColor.FromHtml("#DCFCE7"), XLColor.FromHtml("#166534")),
            SendStatus.Failed => (XLColor.FromHtml("#FEE2E2"), XLColor.FromHtml("#991B1B")),
            _ => (XLColor.FromHtml("#F1F5F9"), XLColor.FromHtml("#475569"))
        };
    }

    public static byte[] ToCsv(SendReport report)
    {
        var builder = new StringBuilder();
        builder.AppendLine(string.Join(",", Headers.Select(Escape)));
        for (var i = 0; i < report.Rows.Count; i++)
        {
            var row = report.Rows[i];
            string[] cells =
            [
                (i + 1).ToString(),
                row.RowNumber.ToString(),
                row.CompanyName,
                row.Email,
                StatusLabel(row.Status),
                row.SentAt?.ToLocalTime().ToString("yyyy-MM-dd HH:mm:ss") ?? "",
                row.Subject,
                row.Attachments,
                row.Detail
            ];
            builder.AppendLine(string.Join(",", cells.Select(Escape)));
        }

        // UTF-8 BOM so Excel shows non-English company names correctly.
        return [.. Encoding.UTF8.GetPreamble(), .. Encoding.UTF8.GetBytes(builder.ToString())];
    }

    public static string StatusLabel(SendStatus status) => status switch
    {
        SendStatus.Sent => "Sent",
        SendStatus.Failed => "Failed",
        _ => "Not sent yet"
    };

    private static string Escape(string? value)
    {
        value ??= "";
        // Stop sheet-sourced text from running as a formula when opened in Excel.
        if (value.Length > 0 && "=+-@\t\r".Contains(value[0]))
        {
            value = "'" + value;
        }

        return value.IndexOfAny([',', '"', '\n', '\r']) >= 0
            ? "\"" + value.Replace("\"", "\"\"") + "\""
            : value;
    }
}
