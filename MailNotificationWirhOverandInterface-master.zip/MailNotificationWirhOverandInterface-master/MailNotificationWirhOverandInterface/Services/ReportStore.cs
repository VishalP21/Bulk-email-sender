using System.Text.Json;
using System.Text.RegularExpressions;
using MailNotificationWirhOverandInterface.Models;

namespace MailNotificationWirhOverandInterface.Services;

public interface IReportStore
{
    SendReport? Get(string? id);

    void Save(SendReport report);

    bool Delete(string? id);

    /// <summary>All saved reports, newest first.</summary>
    IReadOnlyList<SendReport> List();

    /// <summary>For every email that was ever sent successfully: when it was last sent.</summary>
    IReadOnlyDictionary<string, DateTimeOffset> LastSentByEmail();

    /// <summary>The most recent report for the same sheet that shares at least one email, if any.</summary>
    SendReport? FindResumable(string sheetLabel, IEnumerable<string> emails);
}

/// <summary>Keeps send reports as JSON files on this computer so they survive restarts.</summary>
public sealed partial class ReportStore : IReportStore
{
    private static readonly JsonSerializerOptions Json = new() { WriteIndented = false };
    private readonly string _root;
    private readonly ILogger<ReportStore> _logger;
    private readonly object _gate = new();

    public ReportStore(ILogger<ReportStore> logger)
    {
        _logger = logger;
        _root = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "RecruiterMail",
            "reports");
        Directory.CreateDirectory(_root);
    }

    [GeneratedRegex("^[a-f0-9]{32}$")]
    private static partial Regex IdPattern();

    public SendReport? Get(string? id)
    {
        if (!IsValidId(id))
        {
            return null;
        }

        lock (_gate)
        {
            return Read(PathFor(id!));
        }
    }

    public void Save(SendReport report)
    {
        if (!IsValidId(report.Id))
        {
            report.Id = Guid.NewGuid().ToString("N");
        }

        lock (_gate)
        {
            var path = PathFor(report.Id);
            var temp = path + ".tmp";
            File.WriteAllText(temp, JsonSerializer.Serialize(report, Json));
            File.Move(temp, path, overwrite: true);
        }
    }

    public bool Delete(string? id)
    {
        if (!IsValidId(id))
        {
            return false;
        }

        lock (_gate)
        {
            var path = PathFor(id!);
            if (!File.Exists(path))
            {
                return false;
            }

            File.Delete(path);
            return true;
        }
    }

    public IReadOnlyList<SendReport> List()
    {
        lock (_gate)
        {
            return Directory.EnumerateFiles(_root, "*.json")
                .Select(Read)
                .OfType<SendReport>()
                .OrderByDescending(report => report.FinishedAt)
                .ToList();
        }
    }

    public IReadOnlyDictionary<string, DateTimeOffset> LastSentByEmail()
    {
        var result = new Dictionary<string, DateTimeOffset>(StringComparer.OrdinalIgnoreCase);
        foreach (var row in List().SelectMany(report => report.Rows))
        {
            if (row.Status == SendStatus.Sent && row.SentAt is { } at &&
                (!result.TryGetValue(row.Email, out var known) || at > known))
            {
                result[row.Email] = at;
            }
        }

        return result;
    }

    public SendReport? FindResumable(string sheetLabel, IEnumerable<string> emails)
    {
        var wanted = new HashSet<string>(emails, StringComparer.OrdinalIgnoreCase);
        return List().FirstOrDefault(report =>
            string.Equals(report.SheetLabel, sheetLabel, StringComparison.OrdinalIgnoreCase) &&
            report.Rows.Any(row => wanted.Contains(row.Email)));
    }

    private static bool IsValidId(string? id) => id is not null && IdPattern().IsMatch(id);

    private string PathFor(string id) => Path.Combine(_root, id + ".json");

    private SendReport? Read(string path)
    {
        try
        {
            return File.Exists(path) ? JsonSerializer.Deserialize<SendReport>(File.ReadAllText(path), Json) : null;
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Could not read send report {Path}", path);
            return null;
        }
    }
}
